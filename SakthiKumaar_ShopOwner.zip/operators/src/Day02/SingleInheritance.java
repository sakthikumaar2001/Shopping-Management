package Day02;
/*
//public class SingleInheritance {
	// Single Inheritance
	class father
	{
	    void house()
	    {
	        System.out.println("Father has Own Private Jet.");
	    }
	}
	class son extends father
	{
	    void print()
	    {
	        System.out.println("Son has new House.");
	    }
	}

	public class SingleInheritance {

	  public static void main(String[] args) 
	  {
	    son s=new son();
	    s.print();
	    s.house();

	  }

	}

*/