/*//public class Hierachialinheritance{
	  public static void main(String[] args)
	  {
	    rect r=new rect(4,5);
	        System.out.println("Area of Rect:"+r.rect_area());
	        circle t=new circle(5);
	        System.out.println("Area of circle:"+t.circle_area());
	        square s=new square(6);
	        System.out.println("Area of Square:"+s.square_area());  
	  }

	}

class shape
{
    float length,breadth,radius;
}
class rect extends shape
{
    public rect(float l,float b)
    {
        length=l;
        breadth=b;
    }
    float rect_area()
    {
        return length*breadth;
    }
}
class circle extends shape
{
    public circle(float r)
    {
        radius=r;
    }
    float circle_area()
    {
        return 3.14f*(radius*radius);
    }
}
class square extends shape
{
    public square(float l)
    {
        length=l;
    }
    float square_area()
    {
        return length*length;
    }
}
*/
